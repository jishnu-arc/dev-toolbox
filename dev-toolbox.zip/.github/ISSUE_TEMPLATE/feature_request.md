---
name: Tool or feature request
about: Suggest a new tool or improvement
labels: enhancement
---

**What tool or feature would you like?**

**Why is it useful?**
